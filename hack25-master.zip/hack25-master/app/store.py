# Temporary in-memory message queue. You may persist this to a database in production.
message_queue = []
# Temporary in-memory vote options mapping. Consider storing in a database for long-term storage.
vote_option_map = {}